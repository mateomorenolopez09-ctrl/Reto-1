
let frase = prompt("Ingresa una frase:");
function convertirATitulo(texto) {
  let palabras = texto.split(" "); 
  let resultado = "";

  for (let i = 0; i < palabras.length; i++) {
    let palabra = palabras[i];
    let primeraLetra = palabra.charAt(0).toUpperCase(); 
    let resto = palabra.slice(1).toLowerCase(); 
    resultado += primeraLetra + resto + " "; 
  }

  return resultado.trim(); 
}




let resultado = convertirATitulo(frase);
console.log("Frase en formato título:", resultado);
