function promedioMayoresQueLimite(numeros, limite) {
  let suma = 0;
  let contador = 0;

  for (let i = 0; i < numeros.length; i++) {
    if (numeros[i] > limite) {
      suma += numeros[i];
      contador++;
    }
  }

  if (contador === 0) {
    return 0; // Si no hay números mayores que el límite
  }

  return suma / contador;
}

// 🔹 Llamado de la función
let arreglo = [5, 12, 8, 20, 3];
let limite = 10;

let resultado = promedioMayoresQueLimite(arreglo, limite);
console.log("El promedio de los números mayores que el límite es:", resultado);