let numero = parseInt(prompt("Ingresa un número entero:"));
function convertirABinario(numero) {
  let binario = "";

  if (numero === 0) {
    return "0";
  }

  while (numero > 0) {
    let residuo = numero % 2; 
    binario = residuo + binario; 
    numero = Math.floor(numero / 2); 
  }

  return binario;
}

let resultado = convertirABinario(numero);
console.log("La representación binaria es:", resultado);
