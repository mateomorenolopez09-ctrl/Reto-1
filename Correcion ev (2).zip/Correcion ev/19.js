let indice1 = parseInt(prompt("Ingresa el primer índice:"));
let indice2 = parseInt(prompt("Ingresa el segundo índice:"));

function intercambiarElementos(arreglo, indice1, indice2) {
 
  if (indice1 < 0 || indice2 < 0 || indice1 >= arreglo.length || indice2 >= arreglo.length) {
    console.log(" Uno o ambos índices no existen en el arreglo.");
    return arreglo; 
  }

  
  let temporal = arreglo[indice1];
  arreglo[indice1] = arreglo[indice2];
  arreglo[indice2] = temporal;

  return arreglo;
}


let arreglo = [10, 20, 30, 40, 50];

let resultado = intercambiarElementos(arreglo, indice1, indice2);
console.log("Arreglo resultante:", resultado);
