function sumarImpares(numeros) {
  let suma = 0;

  for (let i = 0; i < numeros.length; i++) {
    if (numeros[i] % 2 !== 0) { 
      suma += numeros[i];
    }
  }

  return suma;
}


let cantidad = parseInt(prompt("¿Cuántos números vas a ingresar?"));
let arreglo = [];

for (let i = 0; i < cantidad; i++) {
  let numero = parseInt(prompt("Ingresa el número " + (i + 1) + ":"));
  arreglo.push(numero);
}

let resultado = sumarImpares(arreglo);
console.log("La suma de los números impares es:", resultado);
