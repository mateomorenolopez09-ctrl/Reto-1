let temperatura = parseFloat(prompt("Ingresa la temperatura:"));
let tipo = prompt("Ingresa el tipo de conversión: 'C' para convertir a Fahrenheit o 'F' para convertir a Celsius:");
function convertirTemperatura(temperatura, tipo) {
  let resultado;

  if (tipo === "C") {
   
    resultado = (temperatura * 9/5) + 32;
  } 
  else if (tipo === "F") {
    
    resultado = (temperatura - 32) * 5/9;
  } 
  else {
    console.log("Tipo de conversión no válido. Usa 'C' o 'F'.");
    return;
  }

  return resultado;
}



let resultado = convertirTemperatura(temperatura, tipo);

console.log("La temperatura convertida es:", resultado);
