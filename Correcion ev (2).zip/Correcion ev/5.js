
let base = parseInt(prompt("Ingresa la base:"));
let exponente = parseInt(prompt("Ingresa el exponente:"));

function calcularPotencia(base, exponente) {
  let resultado = 1;

  for (let i = 1; i <= exponente; i++) {
    resultado *= base;
  }

  return resultado;
}


let potencia = calcularPotencia(base, exponente);
console.log(base, "elevado a", exponente, "es:", potencia);
