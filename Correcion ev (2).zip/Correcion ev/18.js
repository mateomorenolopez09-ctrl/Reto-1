let frase = prompt("Ingresa una frase:");
let letra = prompt("Ingresa una letra:");

function contarPalabrasPorLetra(frase, letra) {
  let palabras = frase.split(" ");
  let contador = 0;

  for (let i = 0; i < palabras.length; i++) {
    if (palabras[i][0].toLowerCase() === letra.toLowerCase()) {
      contador++;
    }
  }

  return contador;
}


let resultado = contarPalabrasPorLetra(frase, letra);
console.log(`Hay ${resultado} palabra(s) que inician con la letra "${letra}".`);
