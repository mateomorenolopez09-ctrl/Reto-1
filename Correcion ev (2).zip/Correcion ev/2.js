function palabrasPorLongitud(palabras, numero) {
  let resultado = [];

  for (let i = 0; i < palabras.length; i++) {
    if (palabras[i].length === numero) {
      resultado.push(palabras[i]);
    }
  }

  return resultado;
}


let arreglo = ["sol", "luna", "estrella", "mar", "cielo"];
let cantidad = 3;

let resultado = palabrasPorLongitud(arreglo, cantidad);
console.log("Palabras con", cantidad, "letras:", resultado);
