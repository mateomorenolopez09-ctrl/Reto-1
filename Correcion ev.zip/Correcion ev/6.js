let inicio = parseInt(prompt("Ingresa el número de inicio:"));
let fin = parseInt(prompt("Ingresa el número final:"));
function numerosPrimos(inicio, fin) {
  let primos = [];

  for (let i = inicio; i <= fin; i++) {
    if (i < 2) continue; 
    let esPrimo = true;

    
    for (let j = 2; j < i; j++) {
      if (i % j === 0) {
        esPrimo = false;
        break;
      }
    }

    if (esPrimo) {
      primos.push(i);
    }
  }

  return primos;
}


let resultado = numerosPrimos(inicio, fin);
console.log("Los números primos entre", inicio, "y", fin, "son:", resultado);
