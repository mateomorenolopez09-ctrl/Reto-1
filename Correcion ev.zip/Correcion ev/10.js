function multiplicarHastaLimite(numeros, limite) {
  let producto = 1;

  for (let i = 0; i < numeros.length; i++) {
    producto *= numeros[i];

    if (producto > limite) {
      console.log("🔸 Se detuvo porque el producto superó el límite.");
      break; 
    }
  }

  return producto;
}


let cantidad = parseInt(prompt("¿Cuántos números vas a ingresar?"));
let arreglo = [];

for (let i = 0; i < cantidad; i++) {
  let numero = parseInt(prompt("Ingresa el número " + (i + 1) + ":"));
  arreglo.push(numero);
}

let limite = parseInt(prompt("Ingresa el límite máximo:"));

let resultado = multiplicarHastaLimite(arreglo, limite);
console.log("El resultado final es:", resultado);
