
let edad = (prompt("Ingresa tu edad:"));

if (edad >= 1 && edad <= 13) { 
  console.log("Eres un niño");
} 
else if (edad >= 14 && edad <= 17) {
  console.log("Eres un adolescente");
} 
else if (edad >= 18 && edad <= 60) {
  console.log("Eres un adulto");
} 
else if (edad >= 61 && edad <= 100) {
  console.log("Eres un adulto mayor");
} 
else {
  console.log("Edad no válida");
}
