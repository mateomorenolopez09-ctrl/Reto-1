let cantidad = parseInt(prompt("¿Cuántos números vas a ingresar?"));
function separarNumeros(numeros) {
  let positivos = [];
  let negativos = [];

  for (let i = 0; i < numeros.length; i++) {
    if (numeros[i] >= 0) {
      positivos.push(numeros[i]);
    } else {
      negativos.push(numeros[i]);
    }
  }

  return [positivos, negativos];
}



let arreglo = [];

for (let i = 0; i < cantidad; i++) {
  let numero = parseInt(prompt("Ingresa el número " + (i + 1) + ":"));
  arreglo.push(numero);
}

let resultado = separarNumeros(arreglo);
console.log("Números positivos:", resultado[0]);
console.log("Números negativos:", resultado[1]);
