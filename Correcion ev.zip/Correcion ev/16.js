let cantidad = parseInt(prompt("¿Cuántos números vas a ingresar?"));
function contarMayoresQuePromedio(arreglo) {
  let suma = 0;

  
  for (let i = 0; i < arreglo.length; i++) {
    suma += arreglo[i];
  }

  let promedio = suma / arreglo.length;
  let contador = 0;

  
  for (let i = 0; i < arreglo.length; i++) {
    if (arreglo[i] > promedio) {
      contador++;
    }
  }

  console.log("El promedio es:", promedio);
  return contador;
}


let arreglo = [];

for (let i = 0; i < cantidad; i++) {
  let numero = parseFloat(prompt("Ingresa el número " + (i + 1) + ":"));
  arreglo.push(numero);
}


let resultado = contarMayoresQuePromedio(arreglo);
console.log("Cantidad de números mayores que el promedio:", resultado);
