let texto = prompt("Ingresa una palabra o frase:");

  let vocales = 0;
  let consonantes = 0;
  cadena = cadena.toLowerCase();

  for (let i = 0; i < cadena.length; i++) {
    let letra = cadena[i];

    if (letra === "a" || letra === "e" || letra === "i" || letra === "o" || letra === "u") {
      vocales++;
    } else if (letra >= "a" && letra <= "z") {
      consonantes++;
    }
  }

  console.log("Vocales:", vocales);
  console.log("Consonantes:", consonantes);





