let palabra = prompt("Ingresa una palabra o frase:");
function esPalindromo(texto) {
 
  texto = texto.toLowerCase().replaceAll(" ", "");

  let longitud = texto.length;

  for (let i = 0; i < longitud / 2; i++) {
    if (texto[i] !== texto[longitud - 1 - i]) {
      return false; 
    }
  }

  return true; 
}

if (esPalindromo(palabra)) {
  console.log(" Es un palíndromo");
} else {
  console.log(" No es un palíndromo");
}
