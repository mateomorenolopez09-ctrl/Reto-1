function validarContrasena(contrasena) {
  
  let tieneMayuscula = false;
  let tieneNumero = false;
  let tieneEspecial = false;

  
  if (contrasena.length < 8) {
    return false;
  }

  
  for (let i = 0; i < contrasena.length; i++) {
    let char = contrasena[i];

    if (char >= "A" && char <= "Z") {
      tieneMayuscula = true;
    } else if (char >= "0" && char <= "9") {
      tieneNumero = true;
    } else if ("!@#$%^&*()_-+=<>?/{}[]~".includes(char)) {
      tieneEspecial = true;
    }
  }

 
  if (tieneMayuscula && tieneNumero && tieneEspecial) {
    return true;
  } else {
    return false;
  }
}


let contrasena = prompt("Ingresa una contraseña para validar:");

if (validarContrasena(contrasena)) {
  console.log(" Contraseña segura");
} else {
  console.log(" Contraseña insegura (debe tener al menos 8 caracteres, una mayúscula, un número y un símbolo).");
}
