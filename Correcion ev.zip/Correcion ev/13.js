let cantidad = parseInt(prompt("¿Cuántos números vas a ingresar?"));
function eliminarDuplicados(arreglo) {
  let nuevoArreglo = [];

  for (let i = 0; i < arreglo.length; i++) {
    if (!nuevoArreglo.includes(arreglo[i])) {
      nuevoArreglo.push(arreglo[i]);
    }
  }

  return nuevoArreglo;
}

let arreglo = [];

for (let i = 0; i < cantidad; i++) {
  let numero = parseInt(prompt("Ingresa el número " + (i + 1) + ":"));
  arreglo.push(numero);
}


let resultado = eliminarDuplicados(arreglo);
console.log("Arreglo sin duplicados:", resultado);
